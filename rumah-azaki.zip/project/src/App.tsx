import React, { useState } from 'react';
import { 
  Heart, 
  Users, 
  Target, 
  Phone, 
  Mail, 
  MapPin, 
  ChevronRight, 
  Star,
  CheckCircle,
  HandHeart,
  UserCheck,
  Award,
  ArrowUp
} from 'lucide-react';

function App() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm shadow-sm z-50 transition-all duration-300">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-green-600 rounded-xl flex items-center justify-center">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Rumah Azaki</h1>
                <p className="text-xs text-gray-600">Lembaga Kesejahteraan Sosial</p>
              </div>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#tentang" className="text-gray-700 hover:text-blue-600 transition-colors">Tentang</a>
              <a href="#program" className="text-gray-700 hover:text-blue-600 transition-colors">Program</a>
              <a href="#donasi" className="text-gray-700 hover:text-blue-600 transition-colors">Donasi</a>
              <a href="#kontak" className="text-gray-700 hover:text-blue-600 transition-colors">Kontak</a>
            </div>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition-colors font-small">
              Donasi Sekarang
            </button>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-16 bg-gradient-to-br from-blue-50 to-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Award className="h-4 w-4 mr-2" />
                Lembaga Kesejahteraan Sosial Resmi
              </div>
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Bersama Membangun
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-600"> Harapan</span>
              </h1>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                Rumah Azaki adalah pusat rehabilitasi yang berdedikasi untuk penyandang disabilitas dan anak-anak berkebutuhan khusus. Mari bergabung dalam misi mulia ini.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-blue-600 text-white px-8 py-4 rounded-full hover:bg-blue-700 transition-all duration-300 font-medium text-lg flex items-center justify-center group">
                  Mulai Berdonasi
                  <ChevronRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-full hover:bg-blue-600 hover:text-white transition-all duration-300 font-medium text-lg">
                  Pelajari Lebih Lanjut
                </button>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
                <img 
                  src="/image.png" 
                  alt="Rumah Azaki - Pusat Rehabilitasi Penyandang Disabilitas" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl p-4 shadow-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm font-medium">Aktif Melayani</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">500+</div>
              <p className="text-gray-600">Penerima Manfaat</p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">50+</div>
              <p className="text-gray-600">Program Rehabilitasi</p>
            </div>
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <UserCheck className="h-8 w-8 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">25+</div>
              <p className="text-gray-600">Tenaga Ahli</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">10+</div>
              <p className="text-gray-600">Tahun Pengalaman</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="tentang" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Tentang Rumah Azaki</h2>
              <p className="text-xl text-gray-700 mb-6">
                Sebagai Lembaga Kesejahteraan Sosial yang resmi, kami berkomitmen memberikan layanan terbaik 
                untuk rehabilitasi dan pemberdayaan penyandang disabilitas serta anak berkebutuhan khusus.
              </p>
              <p className="text-gray-600 mb-8">
                Dengan tim tenaga ahli yang berpengalaman dan fasilitas yang memadai, kami telah membantu 
                ratusan keluarga dalam memberikan perawatan dan terapi yang tepat untuk anak-anak istimewa mereka.
              </p>
              <div className="flex items-center space-x-4">
                <div className="bg-blue-100 p-3 rounded-xl">
                  <Award className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Lembaga Kesejahteraan Sosial Resmi</p>
                  <p className="text-sm text-gray-600">Terdaftar dan diakui pemerintah</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src="/image.png" 
                  alt="Kegiatan di Rumah Azaki - Terima kasih berasnya sudah diterima" 
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                <div className="flex items-center space-x-3">
                  <Heart className="h-6 w-6 text-red-500" />
                  <div>
                    <p className="font-semibold text-gray-900">Bantuan Terdistribusi</p>
                    <p className="text-sm text-gray-600">Dengan transparansi penuh</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="bg-blue-100 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Target className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Visi Kami</h3>
              <p className="text-gray-700">
                Menjadi pusat rehabilitasi terdepan yang memberikan harapan dan kemandirian 
                bagi penyandang disabilitas dan anak berkebutuhan khusus.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="bg-green-100 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <HandHeart className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Misi Kami</h3>
              <p className="text-gray-700">
                Menyediakan layanan rehabilitasi komprehensif, pendampingan keluarga, 
                dan program pemberdayaan yang berkelanjutan.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="bg-purple-100 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <CheckCircle className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Komitmen</h3>
              <p className="text-gray-700">
                Mengutamakan kualitas layanan, pendekatan individual, dan kolaborasi 
                dengan keluarga untuk hasil optimal.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Programs Section */}
      <section id="program" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Program Unggulan</h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Berbagai program rehabilitasi dan pemberdayaan yang dirancang khusus 
              untuk kebutuhan setiap individu.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="group bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-2xl hover:from-blue-100 hover:to-blue-200 transition-all duration-300">
              <div className="bg-blue-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Terapi Fisik</h3>
              <p className="text-gray-700">
                Program rehabilitasi fisik komprehensif dengan peralatan modern dan tenaga ahli berpengalaman.
              </p>
            </div>

            <div className="group bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-2xl hover:from-green-100 hover:to-green-200 transition-all duration-300">
              <div className="bg-green-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Terapi Wicara</h3>
              <p className="text-gray-700">
                Layanan terapi wicara dan komunikasi untuk meningkatkan kemampuan berbicara dan berinteraksi.
              </p>
            </div>

            <div className="group bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-2xl hover:from-purple-100 hover:to-purple-200 transition-all duration-300">
              <div className="bg-purple-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Target className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Terapi Okupasi</h3>
              <p className="text-gray-700">
                Program pelatihan keterampilan hidup dan kemandirian untuk aktivitas sehari-hari.
              </p>
            </div>

            <div className="group bg-gradient-to-br from-orange-50 to-orange-100 p-8 rounded-2xl hover:from-orange-100 hover:to-orange-200 transition-all duration-300">
              <div className="bg-orange-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Award className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Pendidikan Khusus</h3>
              <p className="text-gray-700">
                Program pendidikan yang disesuaikan dengan kebutuhan dan kemampuan setiap anak.
              </p>
            </div>

            <div className="group bg-gradient-to-br from-teal-50 to-teal-100 p-8 rounded-2xl hover:from-teal-100 hover:to-teal-200 transition-all duration-300">
              <div className="bg-teal-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <HandHeart className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Bimbingan Keluarga</h3>
              <p className="text-gray-700">
                Pendampingan dan edukasi untuk keluarga dalam merawat anak berkebutuhan khusus.
              </p>
            </div>

            <div className="group bg-gradient-to-br from-pink-50 to-pink-100 p-8 rounded-2xl hover:from-pink-100 hover:to-pink-200 transition-all duration-300">
              <div className="bg-pink-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <UserCheck className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Keterampilan Vokasi</h3>
              <p className="text-gray-700">
                Program pelatihan keterampilan kerja untuk mempersiapkan kemandirian ekonomi.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Testimoni</h2>
            <p className="text-xl text-gray-700">Cerita inspiratif dari keluarga yang telah merasakan manfaatnya</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-700 mb-6">
                "Rumah Azaki telah memberikan harapan baru untuk anak saya. Program terapi yang komprehensif 
                dan tenaga ahli yang profesional membuat perkembangan yang luar biasa."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-blue-600 font-semibold">RS</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Ratih S.</p>
                  <p className="text-gray-600 text-sm">Orang Tua</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-700 mb-6">
                "Pelayanan yang sangat baik dan penuh kasih sayang. Anak saya mengalami kemajuan pesat 
                dalam kemampuan berkomunikasi setelah mengikuti terapi di sini."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-green-600 font-semibold">AP</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Ahmad P.</p>
                  <p className="text-gray-600 text-sm">Orang Tua</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-700 mb-6">
                "Tim terapis yang sangat berpengalaman dan sabar. Mereka tidak hanya membantu anak, 
                tetapi juga memberikan edukasi kepada kami sebagai orang tua."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-purple-600 font-semibold">SM</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Sari M.</p>
                  <p className="text-gray-600 text-sm">Orang Tua</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Donation CTA */}
      <section id="donasi" className="py-20 bg-gradient-to-br from-blue-600 to-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Mari Bergabung Membantu</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-3xl mx-auto">
            Setiap donasi Anda akan memberikan dampak nyata bagi kehidupan penyandang disabilitas 
            dan anak berkebutuhan khusus. Bersama kita wujudkan Indonesia yang lebih inklusif.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-2xl">
              <div className="text-3xl font-bold text-white mb-2">100K</div>
              <p className="text-blue-100">Satu sesi terapi</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-2xl">
              <div className="text-3xl font-bold text-white mb-2">500K</div>
              <p className="text-blue-100">Program terapi bulanan</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-2xl">
              <div className="text-3xl font-bold text-white mb-2">2JT</div>
              <p className="text-blue-100">Sponsor anak satu tahun</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-full hover:bg-blue-50 transition-colors font-semibold text-lg">
              Donasi Sekarang
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-full hover:bg-white hover:text-blue-600 transition-colors font-semibold text-lg">
              Jadi Relawan
            </button>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="kontak" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Hubungi Kami</h2>
            <p className="text-xl text-gray-700">
              Tim kami siap membantu menjawab pertanyaan dan memberikan informasi lebih lanjut
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Telepon</h3>
                    <p className="text-gray-700">0821-5926-6422 (Ibu Lili)</p>
                    <p className="text-sm text-gray-600">Senin - Jumat, 08.00 - 17.00 WIB</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Mail className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Email</h3>
                    <p className="text-gray-700">info@rumahazaki.org</p>
                    <p className="text-sm text-gray-600">Respon dalam 24 jam</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Lokasi</h3>
                    <p className="text-gray-700">Jalan Kemanusiaan No. 123</p>
                    <p className="text-gray-700">Jakarta Selatan, DKI Jakarta</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-8 rounded-2xl">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Kirim Pesan</h3>
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama Lengkap</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                    placeholder="Masukkan nama lengkap"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input 
                    type="email" 
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                    placeholder="nama@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Pesan</label>
                  <textarea 
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all resize-none"
                    placeholder="Tulis pesan Anda di sini..."
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 transition-colors font-medium"
                >
                  Kirim Pesan
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-green-600 rounded-xl flex items-center justify-center">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Rumah Azaki</h3>
                  <p className="text-gray-400 text-sm">Lembaga Kesejahteraan Sosial</p>
                </div>
              </div>
              <p className="text-gray-400 mb-4">
                Berkomitmen memberikan layanan rehabilitasi terbaik bagi penyandang disabilitas 
                dan anak berkebutuhan khusus untuk kehidupan yang lebih mandiri dan bermakna.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Layanan</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Terapi Fisik</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terapi Wicara</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terapi Okupasi</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pendidikan Khusus</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Informasi</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Tentang Kami</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Program</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Donasi</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Kontak</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm">
                © 2025 Rumah Azaki. Semua hak dilindungi undang-undang.
              </p>
              <p className="text-gray-400 text-sm mt-4 md:mt-0">
                Lembaga Kesejahteraan Sosial Resmi
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg hover:bg-blue-700 transition-all duration-300 flex items-center justify-center group z-50"
        >
          <ArrowUp className="h-6 w-6 group-hover:-translate-y-1 transition-transform" />
        </button>
      )}
    </div>
  );
}

export default App;